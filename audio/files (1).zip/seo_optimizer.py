from config import *
import random

class SEOOptimizer:
    """Generate SEO-optimized metadata for women shoppers"""
    
    def __init__(self):
        self.keywords = SEO_KEYWORDS
    
    def generate_title(self, products, video_type="shorts", template=None):
        """
        Generate SEO-optimized title
        Focus: Women shoppers, USA, trending, new arrivals
        """
        product_name = products[0]['title'][:30]
        
        if video_type == "shorts":
            templates = [
                f"✨ {product_name} - Women's Trending Style 2025",
                f"💕 NEW: {product_name} - Perfect for You",
                f"🛍️ Just Dropped - {product_name} | Women Fashion",
                f"Women LOVE This! {product_name} | Trending Now",
                f"NEW IN: {product_name} - Women's Fashion Must-Have",
                f"🔥 Trending: {product_name} - Women's Style",
                f"✨ Women's Fashion: {product_name} - Shop Now",
                f"💃 Style Alert: {product_name} - Women Fashion"
            ]
        else:
            # Regular video titles
            collection_name = template.replace("_", " ").title() if template else "Collection"
            templates = [
                f"{collection_name} - Women's Must-Have Items",
                f"Women's {collection_name} - Trending Styles & Looks",
                f"New Arrivals for Women - {collection_name} Edition",
                f"Women's {collection_name} Picks - Style Inspiration",
                f"Top Picks for Women - {collection_name} Favorites",
                f"Women Fashion: {collection_name} | Latest Trends",
                f"Shop Women's {collection_name} - Style Ideas"
            ]
        
        return random.choice(templates)
    
    def generate_description(self, products, video_type="shorts", collection_name=None):
        """
        Generate SEO description with CTAs and product URLs
        Optimize for: women, USA, new arrivals, trending
        """
        if video_type == "shorts":
            desc = "🛍️ FEATURED PRODUCTS:\n\n"
            
            for product in products:
                price_display = f"${product['price']}"
                desc += f"• {product['title']}\n  Price: {price_display}\n\n"
            
            desc += """✨ SHOP WITH US
💫 Exclusive for Women Shoppers in USA
👗 Free Shipping on Orders $50+
💕 New Arrivals Weekly
🚚 Fast & Secure Delivery

👇 SHOP NOW - Link in Comments 👇
"""
        else:
            collection = collection_name or "New Collection"
            desc = f"""✨ {collection.upper()} FOR WOMEN

🛍️ Curated styles perfect for every occasion
👗 Trending now among US women shoppers
💕 Shop sustainable & quality fashion
✨ New pieces added every week

FEATURED IN THIS VIDEO:
"""
            for product in products:
                desc += f"• {product['title']} - ${product['price']}\n"
            
            desc += """\n💫 WHY SHOP WITH US
✓ Women-owned business
✓ Free shipping USA
✓ 30-day returns
✓ Quality guaranteed

👇 SHOP COLLECTION - Link Below 👇
"""
        
        # Add product URLs
        desc += "\n🔗 SHOP NOW:\n"
        for product in products:
            desc += f"{product['url']}\n"
        
        # Hashtags for discoverability
        desc += "\n#WomensFashion #ShoppingHaul #TrendingNow #NewArrivals #FashionHaul #StyleInspo #ShopSmall #WomenStyle #FashionTrends #OnlineShopping #USAMade #SupportSmall"
        
        return desc
    
    def generate_tags(self, products, video_type="shorts", template=None):
        """
        Generate tags for maximum reach to women shoppers
        YouTube allows up to 30 tags
        """
        tags = [
            # Core audience
            "womensfashion",
            "womensshop",
            "womensstyle",
            "fashionforwomen",
            
            # Trending & discovery
            "trending",
            "trendingfashion",
            "fashiontrends",
            "shoptok",
            "shopnow",
            "shoppinghaul",
            
            # Style & inspiration
            "styleinspo",
            "fashioninspo",
            "outfitidea",
            "stylegoal",
            "lookbook",
            
            # Community & engagement
            "fashionblogger",
            "fashioncommunity",
            "supportsmall",
            "smallbusiness",
            
            # Content type
            "newarrivals",
            "bestsellers",
            "fashionhaul",
            
            # Geography
            "usafashion",
            "usaonline",
            "americanfashion",
            
            # Engagement boosters
            "likeandsubscribe",
            "showitoff",
            "fashionlover",
            "styleadvice"
        ]
        
        # Add product-specific tags
        for product in products:
            words = product['title'].lower().split()
            # Take key words (avoid articles, prepositions)
            for word in words[:3]:
                if len(word) > 3 and word not in ['with', 'from', 'for']:
                    tags.append(word.replace(',', ''))
        
        # Add template-specific tags
        if template:
            template_tags = {
                "style_this": ["stylethis", "fashionlook", "outfitinspo"],
                "get_inspired": ["getinspired", "fashioninspo", "stylegoals"],
                "new_arrivals": ["newarrivals", "justdropped", "shopnew"],
                "best_sellers": ["bestsellers", "popularpicks", "musthaves"],
                "out_of_the_week": ["outoftheweek", "weeklytrends"],
                "out_of_the_day": ["outoftheday", "dailystyle"]
            }
            tags.extend(template_tags.get(template, []))
        
        # Remove duplicates and limit to 30
        tags = list(dict.fromkeys(tags))[:30]
        
        return tags
    
    def generate_metadata_bundle(self, products, video_type="shorts", template=None):
        """Generate complete metadata package"""
        return {
            "title": self.generate_title(products, video_type, template),
            "description": self.generate_description(products, video_type, template),
            "tags": self.generate_tags(products, video_type, template),
            "video_type": video_type,
            "product_count": len(products),
            "template": template
        }
