# YouTube Shorts & Video Generator for Shopify - Implementation Plan

## 🎯 Project Overview
Automated system to generate **YouTube Shorts (30s)** and **Regular Videos (3-day cycle)** featuring in-stock Shopify products with:
- Random mood-based audio (Happy, Inspirational, Folk, Rock, Pop)
- No audio repetition for 10 days
- Women-focused targeting (USA)
- SEO-optimized titles, descriptions, tags
- Product CTAs & URLs
- Popular video templates

---

## 📦 Architecture & Dependencies

### Open-Source Repos Required
```
1. MoviePy - Video creation/editing
   pip install moviepy
   
2. Shopify-Python-API - Product fetching
   pip install ShopifyAPI
   
3. yt-dlp - Audio extraction (optional fallback)
   pip install yt-dlp
   
4. Pillow - Image manipulation
   pip install Pillow
   
5. requests - API calls
   pip install requests
   
6. pytube - YouTube audio extraction
   pip install pytube
   
7. python-dotenv - Env management
   pip install python-dotenv
   
8. sqlite3 - Built-in, audio tracking
```

### High-Quality Video Techniques
- **FFmpeg** (backend for MoviePy) - Install: `pip install imageio-ffmpeg`
- **Pexels API** - Free stock B-roll
- **Unsplash API** - Free lifestyle images
- **Audio blending** - Crossfade for smooth transitions

---

## 📁 File Structure

```
meeeshop-youtube/
├── youtube_shorts.py           # Main execution file (MODIFIED)
├── config.py                   # Configuration & env variables
├── shopify_manager.py          # Shopify API integration
├── youtube_audio_manager.py    # Audio library & tracking
├── video_generator.py          # Video composition
├── seo_optimizer.py            # Title/desc/tags generation
├── templates.py                # Video templates
├── utils.py                    # Helper functions
├── database.db                 # SQLite for audio tracking
├── audio_history.json          # Audio usage log
├── .env                        # Credentials
└── requirements.txt            # Dependencies
```

---

## 🔑 Implementation Steps

### Step 1: Setup Configuration
**File: `config.py`**
```python
import os
from dotenv import load_dotenv

load_dotenv()

# Shopify
SHOPIFY_API_KEY = os.getenv("SHOPIFY_API_KEY")
SHOPIFY_API_PASSWORD = os.getenv("SHOPIFY_API_PASSWORD")
SHOPIFY_STORE = os.getenv("SHOPIFY_STORE")  # e.g., meeeshop.myshopify.com

# YouTube Audio Library (requires setup)
YOUTUBE_AUDIO_MOOD_MAP = {
    "happy": "happy background music tracks",
    "inspirational": "inspirational motivational music",
    "folk": "folk acoustic music",
    "rock": "rock energy music",
    "pop": "pop upbeat music"
}

# Video Settings
VIDEO_DURATION = 30  # seconds
VIDEO_WIDTH = 1080
VIDEO_HEIGHT = 1920  # Vertical for Shorts
VIDEO_FPS = 30
AUDIO_MOOD_ROTATION = ["happy", "inspirational", "folk", "rock", "pop"]
REPEAT_RESTRICTION_DAYS = 10

# Output
OUTPUT_DIR = "generated_videos"
SHORTS_DIR = f"{OUTPUT_DIR}/shorts"
REGULAR_DIR = f"{OUTPUT_DIR}/regular"

# SEO for Women Shoppers (USA)
SEO_KEYWORDS = {
    "women": ["women fashion", "women style", "women trends"],
    "usa": ["USA shipping", "US women"],
    "collections": ["bestsellers", "new arrivals", "trending now"]
}
```

### Step 2: Shopify Manager
**File: `shopify_manager.py`**
```python
import shopify
from config import *

class ShopifyManager:
    def __init__(self):
        shopify.Session.setup(
            api_key=SHOPIFY_API_KEY,
            secret=SHOPIFY_API_PASSWORD,
            api_version="2024-01"
        )
        session = shopify.Session(SHOPIFY_STORE, "2024-01", SHOPIFY_API_PASSWORD)
        shopify.ShopifyResource.activate_session(session)
    
    def get_instock_products(self, limit=5, collection=None):
        """Fetch in-stock products, optionally filtered by collection"""
        query = 'status:active AND inventory:>0'
        if collection:
            query += f' AND collection:{collection}'
        
        products = shopify.Product.find(status="active", limit=limit)
        in_stock = []
        
        for product in products:
            for variant in product.variants:
                if variant.inventory_quantity and variant.inventory_quantity > 0:
                    in_stock.append({
                        "id": product.id,
                        "title": product.title,
                        "image": product.image.src if product.image else None,
                        "price": variant.price,
                        "url": f"https://{SHOPIFY_STORE}/products/{product.handle}",
                        "variant_id": variant.id
                    })
                    break
        
        return in_stock[:limit]
    
    def get_collections(self):
        """Get all collections for template categorization"""
        collections = shopify.CustomCollection.find(limit=250)
        return [{"id": c.id, "title": c.title, "handle": c.handle} for c in collections]
    
    def get_products_by_collection(self, collection_handle, limit=5):
        """Get products from specific collection"""
        return self.get_instock_products(limit=limit, collection=collection_handle)
```

### Step 3: YouTube Audio Manager
**File: `youtube_audio_manager.py`**
```python
import sqlite3
import json
from datetime import datetime, timedelta
import random
from config import *

class AudioManager:
    def __init__(self):
        self.conn = sqlite3.connect('database.db')
        self.setup_db()
    
    def setup_db(self):
        """Create audio tracking table"""
        cursor = self.conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS audio_history (
                id INTEGER PRIMARY KEY,
                mood TEXT,
                audio_url TEXT,
                audio_title TEXT,
                used_date TEXT,
                expires_date TEXT
            )
        ''')
        self.conn.commit()
    
    def get_available_audio(self, mood):
        """
        Get random audio of mood that hasn't been used in last 10 days
        Uses YouTube Audio Library API or free alternatives
        """
        # Check audio history
        cursor = self.conn.cursor()
        cursor.execute('''
            SELECT audio_url FROM audio_history 
            WHERE mood=? AND expires_date > ?
        ''', (mood, datetime.now().isoformat()))
        
        used_audios = [row[0] for row in cursor.fetchall()]
        
        # Fetch from YouTube Audio Library (requires setup)
        available_audio = self._fetch_youtube_audio(mood, exclude=used_audios)
        
        if not available_audio:
            # Fallback to free sources
            available_audio = self._fetch_fallback_audio(mood, exclude=used_audios)
        
        if not available_audio:
            raise Exception(f"No available audio for mood: {mood}")
        
        # Select random and log
        selected = random.choice(available_audio)
        self._log_audio_usage(mood, selected)
        
        return selected
    
    def _fetch_youtube_audio(self, mood, exclude=[]):
        """
        Fetch from YouTube Audio Library
        Requires: YouTube Data API setup
        Returns: [{"title": str, "url": str, "duration": int}]
        """
        # Placeholder - requires YouTube API authentication
        # Sample structure for integration
        moods_query = YOUTUBE_AUDIO_MOOD_MAP.get(mood, mood)
        
        # In production, use official YouTube Audio Library API
        # For MVP: Use free alternatives below
        return []
    
    def _fetch_fallback_audio(self, mood, exclude=[]):
        """Fetch from free audio sources"""
        free_sources = {
            "happy": [
                "https://www.bensound.com/download/ukulele",
                "https://www.bensound.com/download/sunny"
            ],
            "inspirational": [
                "https://www.bensound.com/download/dreams",
                "https://www.bensound.com/download/sunny"
            ],
            "folk": [
                "https://www.bensound.com/download/acoustic",
                "https://www.bensound.com/download/ukulele"
            ],
            "rock": [
                "https://www.bensound.com/download/energy",
                "https://www.bensound.com/download/rock"
            ],
            "pop": [
                "https://www.bensound.com/download/pop",
                "https://www.bensound.com/download/sunny"
            ]
        }
        
        available = [a for a in free_sources.get(mood, []) if a not in exclude]
        return [{"title": f"{mood}_track_{i}", "url": a, "duration": 30} 
                for i, a in enumerate(available)]
    
    def _log_audio_usage(self, mood, audio):
        """Log audio usage for 10-day restriction"""
        cursor = self.conn.cursor()
        used_date = datetime.now().isoformat()
        expires_date = (datetime.now() + timedelta(days=REPEAT_RESTRICTION_DAYS)).isoformat()
        
        cursor.execute('''
            INSERT INTO audio_history (mood, audio_url, audio_title, used_date, expires_date)
            VALUES (?, ?, ?, ?, ?)
        ''', (mood, audio['url'], audio.get('title', 'unknown'), used_date, expires_date))
        
        self.conn.commit()
    
    def get_rotation_mood(self, day_index=0):
        """Get mood for day (cycles through AUDIO_MOOD_ROTATION)"""
        return AUDIO_MOOD_ROTATION[day_index % len(AUDIO_MOOD_ROTATION)]
```

### Step 4: Video Generator
**File: `video_generator.py`**
```python
from moviepy.editor import *
from PIL import Image, ImageDraw, ImageFont
import requests
from io import BytesIO
from config import *

class VideoGenerator:
    def __init__(self):
        self.width = VIDEO_WIDTH
        self.height = VIDEO_HEIGHT
    
    def create_shorts_video(self, products, audio_url, template_type="lifestyle"):
        """Create 30-sec YouTube Short"""
        clips = []
        
        # Add intro text clip (3 sec)
        intro = self._create_text_clip("🛍️ New Arrivals", duration=3)
        clips.append(intro)
        
        # Product showcase (varying by template)
        for product in products[:2]:  # Max 2 products in 30sec
            product_clip = self._create_product_clip(product, duration=8)
            clips.append(product_clip)
        
        # CTA closing (3 sec)
        cta_clip = self._create_cta_clip(products[0], duration=3)
        clips.append(cta_clip)
        
        # Concatenate video
        final_video = concatenate_videoclips(clips)
        
        # Add audio
        audio_clip = AudioFileClip(audio_url).set_duration(final_video.duration)
        final_video = final_video.set_audio(audio_clip)
        
        return final_video
    
    def create_regular_video(self, products, audio_url, template_type):
        """Create regular video (60-120 sec) with template style"""
        clips = []
        
        # Template variations
        if template_type == "style_this":
            clips = self._template_style_this(products, duration=90)
        elif template_type == "get_inspired":
            clips = self._template_get_inspired(products, duration=100)
        elif template_type == "new_arrivals":
            clips = self._template_new_arrivals(products, duration=80)
        elif template_type == "best_sellers":
            clips = self._template_best_sellers(products, duration=85)
        
        final_video = concatenate_videoclips(clips)
        audio_clip = AudioFileClip(audio_url).set_duration(final_video.duration)
        final_video = final_video.set_audio(audio_clip)
        
        return final_video
    
    def _create_product_clip(self, product, duration=8):
        """Create clip with product image and text overlay"""
        img = Image.new('RGB', (self.width, self.height), color=(245, 245, 245))
        draw = ImageDraw.Draw(img)
        
        # Download product image
        if product['image']:
            response = requests.get(product['image'])
            product_img = Image.open(BytesIO(response.content))
            product_img.thumbnail((self.width - 40, self.height - 300), Image.Resampling.LANCZOS)
            img.paste(product_img, ((self.width - product_img.width)//2, 100))
        
        # Add product name and price
        font_title = ImageFont.load_default()
        draw.text((20, self.height - 250), product['title'][:40], fill=(0, 0, 0), font=font_title)
        draw.text((20, self.height - 200), f"${product['price']}", fill=(220, 20, 60), font=font_title)
        draw.text((20, self.height - 150), "👉 Link in Bio", fill=(0, 100, 200), font=font_title)
        
        # Convert to video clip
        img_array = np.array(img)
        clip = ImageClip(img_array).set_duration(duration)
        return clip
    
    def _create_text_clip(self, text, duration=3):
        """Create text overlay clip"""
        clip = TextClip(text, fontsize=70, color='white', font='Arial-Bold',
                       method='caption', size=(self.width-40, None))
        clip = clip.set_position('center').set_duration(duration)
        
        # Add background
        bg = ColorClip(size=(self.width, self.height), color=(20, 20, 20))
        return CompositeVideoClip([bg, clip])
    
    def _create_cta_clip(self, product, duration=3):
        """Create Call-to-Action closing clip"""
        img = Image.new('RGB', (self.width, self.height), color=(220, 20, 60))
        draw = ImageDraw.Draw(img)
        
        draw.text((40, self.height//2 - 100), "SHOP NOW", 
                 fill=(255, 255, 255), font=ImageFont.load_default())
        draw.text((40, self.height//2), product['title'][:30], 
                 fill=(255, 255, 255), font=ImageFont.load_default())
        draw.text((40, self.height//2 + 100), "Link in Bio 👆", 
                 fill=(255, 255, 255), font=ImageFont.load_default())
        
        img_array = np.array(img)
        clip = ImageClip(img_array).set_duration(duration)
        return clip
    
    def _template_style_this(self, products, duration=90):
        """Template: Show styling ideas"""
        return [self._create_product_clip(p, duration=8) for p in products]
    
    def _template_get_inspired(self, products, duration=100):
        """Template: Lifestyle inspiration"""
        return [self._create_product_clip(p, duration=10) for p in products]
    
    def _template_new_arrivals(self, products, duration=80):
        """Template: New products with excitement"""
        return [self._create_product_clip(p, duration=8) for p in products]
    
    def _template_best_sellers(self, products, duration=85):
        """Template: Top sellers"""
        return [self._create_product_clip(p, duration=8.5) for p in products]
```

### Step 5: SEO Optimizer
**File: `seo_optimizer.py`**
```python
from config import *
import random

class SEOOptimizer:
    def __init__(self):
        self.keywords = SEO_KEYWORDS
    
    def generate_title(self, products, video_type="shorts", template=None):
        """Generate SEO-optimized title for women shoppers"""
        if video_type == "shorts":
            templates = [
                f"✨ {products[0]['title']} - Women's Fashion Trend 2025",
                f"💕 New: {products[0]['title']} - Perfect for You",
                f"🛍️ Just Dropped - {products[0]['title']}",
                f"Women Love This! {products[0]['title']} | Trending Now"
            ]
        else:
            templates = [
                f"{template} Collection - Women's Must-Have Items",
                f"New Arrivals for Women - Trending Styles",
                f"Best Sellers - Women Fashion & Lifestyle"
            ]
        
        return random.choice(templates)
    
    def generate_description(self, products, video_type="shorts"):
        """Generate SEO description with CTAs and URLs"""
        desc = ""
        
        if video_type == "shorts":
            desc = f"""🛍️ Shop These Stunning Products:

{chr(10).join([f"• {p['title']} - ${p['price']}" for p in products])}

💫 Exclusive for Women Shoppers in USA
👗 Free Shipping Available
✨ New Arrivals Weekly

🔗 Shop Now:
"""
            desc += "\n".join([p['url'] for p in products])
        else:
            desc = """
🛍️ Collection Favorites for Women

✨ Curated styles perfect for every occasion
👗 Trending now among US women shoppers
💕 Shop sustainable & quality fashion

🔗 Explore Collection:
"""
            desc += "\n".join([p['url'] for p in products])
        
        desc += "\n\n#WomensFashion #ShopNow #TrendingNow #NewArrivals #WomenStyle"
        return desc
    
    def generate_tags(self, products, video_type="shorts"):
        """Generate tags for maximum reach to women shoppers"""
        tags = [
            "womensfashion", "shoptok", "shopnow", "womensstyle",
            "trending", "newarrivals", "fashiontrend", "styleinspo",
            "womenshop", "fashionblogger", "styleforwomen", "womenslook",
            "fashioncommunity", "shoppinghaul", "outfitidea",
            "womenempowerment", "supportsmallbusiness", "usashop"
        ]
        
        # Add product-specific tags
        for product in products:
            words = product['title'].lower().split()
            tags.extend(words[:2])
        
        return tags[:30]  # YouTube limit
```

### Step 6: Templates
**File: `templates.py`**
```python
TEMPLATES = {
    "shorts": [
        "product_showcase",
        "lifestyle_moment",
        "quick_review",
        "trending_now"
    ],
    "regular": {
        "style_this": {
            "description": "Show different styling ideas with same product",
            "duration": 90
        },
        "get_inspired": {
            "description": "Lifestyle inspiration with multiple products",
            "duration": 100
        },
        "out_of_the_week": {
            "description": "Weekly picks and trends",
            "duration": 80
        },
        "out_of_the_day": {
            "description": "Daily style spotlight",
            "duration": 75
        },
        "new_arrivals": {
            "description": "Showcase new products with excitement",
            "duration": 85
        },
        "best_sellers": {
            "description": "Top selling items compilation",
            "duration": 90
        }
    }
}

def get_template_for_day(day_num):
    """Rotate templates: Every 3 days switch from shorts to regular"""
    if day_num % 3 == 0:
        return "regular"
    return "shorts"

def get_regular_template_type(day_num):
    """Rotate template types for regular videos"""
    templates_list = list(TEMPLATES["regular"].keys())
    return templates_list[day_num % len(templates_list)]
```

### Step 7: Utilities
**File: `utils.py`**
```python
import os
from datetime import datetime

def create_dirs():
    """Create output directories"""
    os.makedirs(SHORTS_DIR, exist_ok=True)
    os.makedirs(REGULAR_DIR, exist_ok=True)

def generate_filename(video_type="shorts"):
    """Generate unique filename with timestamp"""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    return f"{video_type}_{timestamp}.mp4"

def get_output_path(video_type="shorts"):
    """Get output path based on video type"""
    if video_type == "shorts":
        return os.path.join(SHORTS_DIR, generate_filename("shorts"))
    return os.path.join(REGULAR_DIR, generate_filename("regular"))
```

---

## 🚀 Main Execution File
**File: `youtube_shorts.py` (MODIFIED)**

```python
#!/usr/bin/env python3
"""
Main execution: Generate YouTube Shorts & Regular Videos
Run daily via cron: 0 0 * * * python /path/to/youtube_shorts.py
"""

import sys
from datetime import datetime
from config import *
from shopify_manager import ShopifyManager
from youtube_audio_manager import AudioManager
from video_generator import VideoGenerator
from seo_optimizer import SEOOptimizer
from templates import get_template_for_day, get_regular_template_type
from utils import create_dirs, get_output_path

def main():
    print(f"🎬 Starting video generation: {datetime.now().isoformat()}")
    
    # Initialize
    create_dirs()
    shopify = ShopifyManager()
    audio_mgr = AudioManager()
    video_gen = VideoGenerator()
    seo = SEOOptimizer()
    
    # Determine video type (shorts every day, regular every 3 days)
    today = datetime.now().day
    video_type = get_template_for_day(today)
    
    print(f"📹 Video Type: {video_type.upper()}")
    
    try:
        if video_type == "shorts":
            # Generate YouTube Short
            products = shopify.get_instock_products(limit=2)
            
            if not products:
                print("❌ No in-stock products found")
                return
            
            mood = audio_mgr.get_rotation_mood(today)
            audio = audio_mgr.get_available_audio(mood)
            
            print(f"🎵 Selected mood: {mood}")
            print(f"🛍️ Products: {[p['title'] for p in products]}")
            
            # Create video
            video = video_gen.create_shorts_video(products, audio['url'], template_type="lifestyle")
            output_path = get_output_path("shorts")
            video.write_videofile(output_path, verbose=False, logger=None)
            
            # Generate metadata
            title = seo.generate_title(products, "shorts")
            description = seo.generate_description(products, "shorts")
            tags = seo.generate_tags(products, "shorts")
            
            print(f"\n✅ SHORT Generated: {output_path}")
            print(f"📝 Title: {title}")
            print(f"🏷️ Tags: {', '.join(tags[:5])}")
            
        else:
            # Generate Regular Video (every 3 days)
            collections = shopify.get_collections()
            collection = collections[today % len(collections)]
            
            products = shopify.get_products_by_collection(collection['handle'], limit=5)
            
            if not products:
                print("❌ No products in collection")
                return
            
            template_type = get_regular_template_type(today)
            mood = audio_mgr.get_rotation_mood(today)
            audio = audio_mgr.get_available_audio(mood)
            
            print(f"🎬 Template: {template_type}")
            print(f"📂 Collection: {collection['title']}")
            print(f"🛍️ Products: {len(products)}")
            
            # Create video
            video = video_gen.create_regular_video(products, audio['url'], template_type)
            output_path = get_output_path("regular")
            video.write_videofile(output_path, verbose=False, logger=None)
            
            # Generate metadata
            title = seo.generate_title(products, "regular", template_type)
            description = seo.generate_description(products, "regular")
            tags = seo.generate_tags(products, "regular")
            
            print(f"\n✅ VIDEO Generated: {output_path}")
            print(f"📝 Title: {title}")
            print(f"🎬 Template: {template_type}")
            
        print(f"\n📊 Metadata Ready for Upload:")
        print(f"Title: {title}")
        print(f"Description: {description[:100]}...")
        print(f"Tags: {', '.join(tags[:10])}")
        
    except Exception as e:
        print(f"❌ Error: {str(e)}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

if __name__ == "__main__":
    main()
```

---

## 📋 Requirements.txt

```
moviepy==1.0.3
imageio-ffmpeg==0.4.8
pillow==10.0.0
shopify==14.4.0
requests==2.31.0
pytube==15.0.0
yt-dlp==2024.1.1
python-dotenv==1.0.0
numpy==1.24.3
imageio==2.31.3
```

---

## 🔧 Setup Instructions

### 1. Install Dependencies
```bash
cd C:\Users\USER\Downloads\Shopify_Claude\meeeshop-youtube
pip install -r requirements.txt
```

### 2. Setup .env File
```
SHOPIFY_API_KEY=your_api_key
SHOPIFY_API_PASSWORD=your_api_password
SHOPIFY_STORE=meeeshop.myshopify.com
```

### 3. YouTube Audio Library Integration
**Free Options (Recommended for MVP):**
- **Bensound.com** - Free high-quality music with attribution
- **FreeSound.org** - Community audio library
- **Pixabay Music** - Royalty-free music

**Premium Option:**
- YouTube Audio Library (requires YouTube account + upload permissions)

### 4. Run First Video
```bash
python youtube_shorts.py
```

### 5. Schedule with Cron (Linux/Mac)
```bash
0 0 * * * python /path/to/youtube_shorts.py
```

**Windows Task Scheduler:**
- Task: `python C:\Users\USER\Downloads\Shopify_Claude\meeeshop-youtube\youtube_shorts.py`
- Trigger: Daily at 12:00 AM

---

## 📊 Data Flow

```
[Shopify API] → [Get Products] 
                    ↓
            [Audio Manager] → [Select Mood] → [Fetch Audio] → [Log Usage]
                    ↓
            [Video Generator] → [Create Clips] → [Add Audio] → [Render]
                    ↓
            [SEO Optimizer] → [Title/Desc/Tags]
                    ↓
        [Output: Video + Metadata]
```

---

## 🎯 Key Features Summary

| Feature | Implementation |
|---------|-----------------|
| 30-sec Shorts | MoviePy concatenation |
| No Audio Repeat (10 days) | SQLite tracking |
| Women-focused SEO | Keyword templates |
| Every 3-day regular video | Day-based logic |
| Multiple templates | Template rotation |
| In-stock products | Shopify API filtering |
| CTA with URL | Dynamic overlay |
| Audio library | Free sources + fallback |

---

## 📈 Optimization Tips

1. **Faster Video Rendering**: Use lower resolution during testing
   ```python
   video.write_videofile(output_path, verbose=False, logger=None, preset='ultrafast')
   ```

2. **Parallel Processing**: Run multiple video generation jobs
   ```bash
   python youtube_shorts.py &
   python youtube_shorts.py &
   ```

3. **Batch Audio Download**: Pre-cache audio files in rotation

4. **Database Cleanup**: Monthly retention
   ```sql
   DELETE FROM audio_history WHERE expires_date < date('now');
   ```

---

## 🔗 Useful Resources

- **MoviePy Docs**: https://zulko.github.io/moviepy/
- **Shopify API**: https://shopify.dev/docs/api/admin-rest
- **FFmpeg Guide**: https://ffmpeg.org/documentation.html
- **YouTube Shorts Specs**: https://support.google.com/youtube/answer/9716234
- **Bensound License**: https://www.bensound.com/licensing

---

## ⚠️ Important Notes

1. **YouTube Shorts Requirements**:
   - Duration: 15-60 seconds ✓
   - Vertical: 9:16 aspect ratio (1080x1920) ✓
   - Audio: Supported ✓
   - Copyright: Use royalty-free music ✓

2. **SEO for Women Shoppers**:
   - Use gender-inclusive keywords
   - Focus on trending styles & lifestyle
   - Include diverse imagery
   - Link products to collections

3. **Audio Licensing**:
   - Always use royalty-free music
   - Track licenses & attributions
   - Never use copyrighted music

4. **Shopify API Rate Limits**:
   - Standard: 2 requests/second
   - Use delays between batch operations

---

## 🚀 Next Steps

1. Copy all Python files to your project directory
2. Update .env with credentials
3. Run `python youtube_shorts.py` manually to test
4. Schedule with cron/Task Scheduler
5. Upload generated videos to YouTube manually or via YouTube Data API
6. Monitor analytics for audience insights

**Expected Timeline**: 15-30 minutes for complete setup with Haiku 4.5
