from datetime import datetime

TEMPLATES = {
    "shorts": {
        "product_showcase": {
            "description": "Quick product showcase with music",
            "duration": 30
        },
        "lifestyle_moment": {
            "description": "Product in lifestyle context",
            "duration": 30
        },
        "quick_review": {
            "description": "Fast-paced product review",
            "duration": 30
        },
        "trending_now": {
            "description": "Current trend spotlight",
            "duration": 30
        }
    },
    "regular": {
        "style_this": {
            "description": "Show different styling ideas with products",
            "duration": 90,
            "products": 3,
            "target": "women"
        },
        "get_inspired": {
            "description": "Lifestyle inspiration with multiple products",
            "duration": 100,
            "products": 4,
            "target": "women"
        },
        "out_of_the_week": {
            "description": "Weekly style picks and trends",
            "duration": 80,
            "products": 4,
            "target": "women"
        },
        "out_of_the_day": {
            "description": "Daily style spotlight and outfit idea",
            "duration": 75,
            "products": 2,
            "target": "women"
        },
        "new_arrivals": {
            "description": "Showcase new products with excitement",
            "duration": 85,
            "products": 4,
            "target": "women"
        },
        "best_sellers": {
            "description": "Top selling items compilation",
            "duration": 90,
            "products": 4,
            "target": "women"
        }
    }
}


def get_video_type_for_day(day_num):
    """
    Determine video type for day
    - Days 0-2: YouTube Shorts
    - Day 3: Regular video
    - Repeat cycle
    """
    cycle_day = day_num % 4
    
    if cycle_day == 3:
        return "regular"
    return "shorts"


def get_shorts_template(day_num):
    """Get YouTube Shorts template for day"""
    template_options = list(TEMPLATES["shorts"].keys())
    return template_options[day_num % len(template_options)]


def get_regular_template(day_num):
    """Get regular video template for day"""
    template_options = list(TEMPLATES["regular"].keys())
    cycle_day = day_num // 4  # Count up every 4-day cycle
    return template_options[cycle_day % len(template_options)]


def get_daily_schedule():
    """Get video schedule for next 12 days"""
    today = datetime.now().day
    schedule = []
    
    for i in range(12):
        day_num = today + i
        video_type = get_video_type_for_day(i)
        
        if video_type == "shorts":
            template = get_shorts_template(i)
        else:
            template = get_regular_template(i)
        
        schedule.append({
            "day": i,
            "type": video_type,
            "template": template,
            "date": f"Day {i}"
        })
    
    return schedule


def print_schedule():
    """Print upcoming video schedule"""
    schedule = get_daily_schedule()
    
    print("\n📅 Video Schedule (Next 12 Days)")
    print("=" * 50)
    
    for item in schedule:
        icon = "🎬" if item['type'] == "shorts" else "📹"
        print(f"{icon} Day {item['day']}: {item['type'].upper()} - {item['template']}")
    
    print("=" * 50)


if __name__ == "__main__":
    print_schedule()
