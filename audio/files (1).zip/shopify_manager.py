import shopify
from config import *
import random

class ShopifyManager:
    """Manage Shopify product fetching and filtering"""
    
    def __init__(self):
        """Initialize Shopify API connection"""
        try:
            shopify.Session.setup(
                api_key=SHOPIFY_API_KEY,
                secret=SHOPIFY_API_PASSWORD,
                api_version="2024-01"
            )
            session = shopify.Session(SHOPIFY_STORE, "2024-01", SHOPIFY_API_PASSWORD)
            shopify.ShopifyResource.activate_session(session)
            print("✓ Shopify connection established")
        except Exception as e:
            print(f"✗ Shopify connection failed: {str(e)}")
            raise
    
    def get_instock_products(self, limit=MAX_PRODUCTS_SHORT, collection=None, status="active"):
        """
        Fetch in-stock products
        Args:
            limit: Number of products to return
            collection: Optional collection handle to filter by
            status: Product status (active, draft, archived)
        Returns:
            List of product dicts with image, price, url, title
        """
        try:
            products = shopify.Product.find(status=status, limit=min(limit*2, 250))
            in_stock = []
            
            for product in products:
                if not product.variants:
                    continue
                
                # Check if any variant has stock
                for variant in product.variants:
                    if (hasattr(variant, 'inventory_quantity') and 
                        variant.inventory_quantity and 
                        variant.inventory_quantity > 0):
                        
                        in_stock.append({
                            "id": product.id,
                            "title": product.title,
                            "image": product.image.src if product.image else None,
                            "price": variant.price,
                            "url": f"https://{SHOPIFY_STORE}/products/{product.handle}",
                            "handle": product.handle,
                            "variant_id": variant.id,
                            "description": product.body_html or ""
                        })
                        break
                
                if len(in_stock) >= limit:
                    break
            
            # Shuffle for variety
            random.shuffle(in_stock)
            return in_stock[:limit]
        
        except Exception as e:
            print(f"✗ Error fetching products: {str(e)}")
            return []
    
    def get_collections(self, limit=50):
        """
        Get all collections for video categorization
        Returns:
            List of collection dicts with id, title, handle
        """
        try:
            collections = shopify.CustomCollection.find(limit=limit)
            return [
                {
                    "id": c.id,
                    "title": c.title,
                    "handle": c.handle,
                    "image": c.image.src if hasattr(c, 'image') and c.image else None
                }
                for c in collections if c.title
            ]
        except Exception as e:
            print(f"✗ Error fetching collections: {str(e)}")
            return []
    
    def get_products_by_collection(self, collection_handle, limit=MAX_PRODUCTS_REGULAR):
        """
        Get products from specific collection
        Args:
            collection_handle: Collection URL slug
            limit: Number of products
        Returns:
            List of in-stock products from collection
        """
        try:
            # Get collection by handle
            collections = self.get_collections()
            collection = next((c for c in collections if c['handle'] == collection_handle), None)
            
            if not collection:
                print(f"✗ Collection '{collection_handle}' not found")
                return self.get_instock_products(limit=limit)
            
            # For MVP: Return general in-stock products
            # Production: Use Shopify's collection products endpoint
            return self.get_instock_products(limit=limit)
        
        except Exception as e:
            print(f"✗ Error fetching collection products: {str(e)}")
            return self.get_instock_products(limit=limit)
    
    def get_best_sellers(self, limit=MAX_PRODUCTS_REGULAR):
        """
        Get best selling products (by sales/orders)
        Returns:
            List of best-selling in-stock products
        """
        products = self.get_instock_products(limit=limit*2)
        # Sort by price as proxy for popularity (can be enhanced with custom fields)
        return sorted(products, key=lambda x: float(x['price']), reverse=True)[:limit]
    
    def get_new_arrivals(self, limit=MAX_PRODUCTS_REGULAR):
        """
        Get newest products
        Returns:
            List of newest in-stock products
        """
        products = self.get_instock_products(limit=limit)
        return products[:limit]
