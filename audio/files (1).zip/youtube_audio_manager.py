import sqlite3
import json
from datetime import datetime, timedelta
import random
import requests
from config import *

class AudioManager:
    """Manage audio selection and 10-day repeat restriction"""
    
    def __init__(self):
        """Initialize audio database"""
        self.conn = sqlite3.connect('database.db')
        self.setup_db()
    
    def setup_db(self):
        """Create audio tracking table if not exists"""
        cursor = self.conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS audio_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                mood TEXT NOT NULL,
                audio_url TEXT NOT NULL,
                audio_title TEXT,
                used_date TEXT NOT NULL,
                expires_date TEXT NOT NULL,
                UNIQUE(mood, audio_url)
            )
        ''')
        self.conn.commit()
    
    def get_available_audio(self, mood):
        """
        Get random audio of specified mood
        - Avoids audio used in last 10 days
        - Returns: {'title': str, 'url': str, 'duration': int}
        """
        if mood not in AUDIO_SOURCES:
            mood = random.choice(list(AUDIO_SOURCES.keys()))
        
        # Get recently used audio (not expired)
        cursor = self.conn.cursor()
        cursor.execute('''
            SELECT audio_url FROM audio_history 
            WHERE mood = ? AND expires_date > ?
        ''', (mood, datetime.now().isoformat()))
        
        used_audios = set(row[0] for row in cursor.fetchall())
        
        # Get available audio
        available = [
            a for a in AUDIO_SOURCES.get(mood, [])
            if a not in used_audios
        ]
        
        if not available:
            # Fallback: use any available audio for mood
            available = AUDIO_SOURCES.get(mood, [])
        
        if not available:
            raise Exception(f"No audio available for mood: {mood}")
        
        # Select random
        selected_url = random.choice(available)
        
        # Log usage
        self._log_audio_usage(mood, selected_url)
        
        return {
            "title": f"{mood}_track_{random.randint(1, 999)}",
            "url": selected_url,
            "duration": 30
        }
    
    def _log_audio_usage(self, mood, audio_url):
        """Log audio usage for 10-day restriction"""
        cursor = self.conn.cursor()
        used_date = datetime.now().isoformat()
        expires_date = (datetime.now() + timedelta(days=REPEAT_RESTRICTION_DAYS)).isoformat()
        
        try:
            cursor.execute('''
                INSERT OR IGNORE INTO audio_history 
                (mood, audio_url, audio_title, used_date, expires_date)
                VALUES (?, ?, ?, ?, ?)
            ''', (mood, audio_url, f"{mood}_track", used_date, expires_date))
            
            self.conn.commit()
            print(f"✓ Audio logged: {mood} - expires {expires_date[:10]}")
        except Exception as e:
            print(f"✗ Error logging audio: {str(e)}")
    
    def get_rotation_mood(self, day_index=0):
        """
        Get mood for specific day
        Cycles through AUDIO_MOOD_ROTATION
        """
        return AUDIO_MOOD_ROTATION[day_index % len(AUDIO_MOOD_ROTATION)]
    
    def get_daily_mood(self):
        """Get today's mood based on current day"""
        day_of_year = datetime.now().timetuple().tm_yday
        return self.get_rotation_mood(day_of_year % len(AUDIO_MOOD_ROTATION))
    
    def download_audio(self, url, output_path):
        """
        Download audio file from URL
        For Bensound: May need session handling
        """
        try:
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
            response = requests.get(url, headers=headers, timeout=30)
            response.raise_for_status()
            
            with open(output_path, 'wb') as f:
                f.write(response.content)
            
            print(f"✓ Audio downloaded: {output_path}")
            return True
        except Exception as e:
            print(f"✗ Error downloading audio: {str(e)}")
            return False
    
    def cleanup_expired(self):
        """Delete expired audio history"""
        cursor = self.conn.cursor()
        cursor.execute(
            'DELETE FROM audio_history WHERE expires_date < ?',
            (datetime.now().isoformat(),)
        )
        deleted = cursor.rowcount
        self.conn.commit()
        print(f"✓ Cleaned up {deleted} expired audio entries")
    
    def get_audio_stats(self):
        """Get audio usage statistics"""
        cursor = self.conn.cursor()
        cursor.execute('SELECT mood, COUNT(*) FROM audio_history GROUP BY mood')
        stats = dict(cursor.fetchall())
        return stats
