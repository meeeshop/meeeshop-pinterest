# ⚡ Quick Start Guide - YouTube Video Generator

## 📦 Installation (5 minutes)

### 1. Copy All Files
```bash
# Navigate to your project directory
cd C:\Users\USER\Downloads\Shopify_Claude\meeeshop-youtube

# Copy all .py files from outputs folder
# Copy requirements.txt
# Copy .env.example
```

### 2. Install Dependencies
```bash
pip install -r requirements.txt
```

**Note**: On first moviepy/imageio-ffmpeg install, it may download FFmpeg (~300MB)

### 3. Setup Environment
```bash
# Copy .env.example to .env
cp .env.example .env

# Edit .env with your Shopify credentials:
# - Get API KEY & PASSWORD from Shopify admin
# - Set SHOPIFY_STORE (e.g., meeeshop.myshopify.com)
```

### 4. Get Shopify Credentials
1. Go to: https://admin.shopify.com/settings/apps-and-integrations/develop-apps
2. Create a new app with:
   - Read products
   - Read collections
   - Read inventory
3. Copy API key & password → .env file

---

## 🚀 First Run

### Test Execution
```bash
python youtube_shorts.py
```

**Expected output:**
- ✓ Shopify connection established
- ✓ Audio selected
- 📹 Creating video... (takes 2-5 minutes)
- ✅ Video generated in `/generated_videos/shorts/`
- 📊 Metadata saved as `shorts_YYYYMMDD_HHMMSS_metadata.json`

---

## 📅 Automation

### Option 1: Windows Task Scheduler

1. **Create batch file** (`run_video_generator.bat`):
```batch
@echo off
cd C:\Users\USER\Downloads\Shopify_Claude\meeeshop-youtube
python youtube_shorts.py
```

2. **Create Task Scheduler Task**:
   - Action: Start a program
   - Program: `C:\Path\To\run_video_generator.bat`
   - Trigger: Daily at 12:00 AM
   - Run whether user is logged in or not

3. **Verify**:
   - Check `/generated_videos/` for new video daily

### Option 2: Cron (Linux/Mac)

```bash
# Edit crontab
crontab -e

# Add line to run at midnight daily:
0 0 * * * /usr/bin/python3 /path/to/youtube_shorts.py >> /path/to/logs/video_gen.log 2>&1
```

### Option 3: Python Scheduler (Cross-platform)

```bash
pip install schedule

# Create scheduler.py:
import schedule
import subprocess
import time

def run_video_gen():
    subprocess.run(["python", "youtube_shorts.py"])

schedule.every().day.at("00:00").do(run_video_gen)

while True:
    schedule.run_pending()
    time.sleep(60)

# Run: python scheduler.py
```

---

## 📁 Output Structure

After first run:
```
meeeshop-youtube/
├── generated_videos/
│   ├── shorts/
│   │   ├── shorts_20250513_120000.mp4
│   │   └── shorts_20250513_120000_metadata.json
│   └── regular/
│       ├── regular_20250516_120000.mp4
│       └── regular_20250516_120000_metadata.json
├── audio_cache/          # Downloaded audio files
├── database.db           # Audio tracking (10-day repeat prevention)
├── youtube_shorts.py     # Main execution
├── config.py             # Settings
├── .env                  # Credentials
└── requirements.txt      # Dependencies
```

---

## 📊 Video Schedule

**Every 4 days:**
- **Day 1-3**: 🎬 YouTube Shorts (30 seconds)
- **Day 4**: 📹 Regular Video (60-120 seconds) with rotating template

**Rotating Templates:**
1. Style This ✨
2. Get Inspired 💕
3. Out of the Week 📅
4. Out of the Day ☀️
5. New Arrivals 🎉
6. Best Sellers ⭐

---

## 🎵 Audio Mood Rotation

Cycles daily through 5 moods (no repeat for 10 days):
1. Happy 🎉
2. Inspirational 💫
3. Folk 🎸
4. Rock 🔥
5. Pop 💃

**Audio Source**: Bensound (royalty-free)

---

## 📝 Generated Metadata

Each video includes JSON file with:
```json
{
  "title": "✨ New Product - Women's Fashion Trend 2025",
  "description": "🛍️ FEATURED PRODUCTS...",
  "tags": ["womensfashion", "trending", "newarrivals", ...],
  "video_type": "shorts",
  "product_count": 2,
  "template": null
}
```

**Use this for YouTube upload:**
1. Upload MP4 file
2. Copy title to title field
3. Copy description to description field
4. Add tags (comma-separated)

---

## 🔧 Troubleshooting

### "No in-stock products found"
- Check Shopify API credentials in .env
- Verify products have inventory > 0
- Ensure API key has product read permissions

### Video rendering slow
- Edit `youtube_shorts.py` line with `preset='ultrafast'` (already set)
- Use lower VIDEO_FPS in config.py (default: 30)
- Reduce VIDEO_WIDTH/HEIGHT for testing

### Audio not downloading
- Check internet connection
- Verify audio URLs in config.py are valid
- Fallback to silence if audio fails (video will be silent)

### "ShopifyAPI not found"
```bash
pip install ShopifyAPI==14.4.0 --force-reinstall
```

---

## 📈 Monitoring

### Check generated videos
```bash
ls -la generated_videos/shorts/    # Linux/Mac
dir generated_videos\shorts\       # Windows
```

### View audio usage stats
```python
from youtube_audio_manager import AudioManager
mgr = AudioManager()
print(mgr.get_audio_stats())
```

### View generation statistics
```bash
python -c "from utils import print_stats; print_stats()"
```

---

## 🚀 Production Checklist

Before going live:

- [ ] Shopify API credentials verified
- [ ] Generated first test video successfully
- [ ] Metadata looks correct for YouTube upload
- [ ] Automation scheduled (Task Scheduler / Cron)
- [ ] Logs being captured
- [ ] Check YouTube Shorts requirements met:
  - [ ] Duration 15-60 seconds ✓
  - [ ] Vertical 9:16 aspect ratio ✓
  - [ ] Royalty-free audio ✓

---

## 📞 Support Resources

- **Shopify API**: https://shopify.dev/docs/api
- **MoviePy Docs**: https://zulko.github.io/moviepy/
- **YouTube Shorts Specs**: https://support.google.com/youtube/answer/9716234
- **Bensound License**: https://www.bensound.com/licensing

---

## ⏱️ Expected Performance

| Task | Time |
|------|------|
| Shopify API calls | 1-2s |
| Audio selection | <1s |
| Video generation (30s short) | 3-5 min |
| Video generation (90s regular) | 5-8 min |
| Metadata generation | <1s |
| **Total per video** | **5-10 min** |

**Optimization**: Run at off-peak hours (e.g., midnight) to avoid CPU competition

---

## 🎯 Next Steps

1. ✅ Install and test
2. ✅ Schedule automation
3. ✅ Monitor first week of videos
4. ✅ Adjust SEO keywords based on analytics
5. ✅ Scale to multiple collections/product categories
6. ✅ Consider YouTube Data API for direct uploads

**Happy video generating! 🎬**
