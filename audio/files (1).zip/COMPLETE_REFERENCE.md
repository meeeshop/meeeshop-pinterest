# 📚 Complete Reference Guide

## 🎯 Project Summary

**Goal**: Automated YouTube content generation for Shopify store targeting women shoppers in USA
- **30-second YouTube Shorts**: Daily (with 10-day audio no-repeat system)
- **Full-length Videos**: Every 3 days (with 6 rotating templates)
- **SEO Optimized**: Title, description, tags for women/USA audience
- **High Quality**: Uses MoviePy + FFmpeg for professional rendering

---

## 📦 Deliverables

### Python Files (8 files)
1. **youtube_shorts.py** - Main execution script
2. **config.py** - Configuration and settings
3. **shopify_manager.py** - Shopify API integration
4. **youtube_audio_manager.py** - Audio selection + 10-day tracking
5. **video_generator.py** - Video composition (MoviePy)
6. **seo_optimizer.py** - Title/description/tags generation
7. **templates.py** - Video template definitions and rotation
8. **utils.py** - Utility functions and helpers

### Configuration Files
- **requirements.txt** - All Python dependencies
- **.env.example** - Template for environment variables
- **IMPLEMENTATION_PLAN.md** - Detailed technical plan
- **QUICK_START.md** - Setup and usage guide

---

## 🔄 Workflow Overview

```
┌─────────────────────────────────────────────────────────┐
│           DAILY VIDEO GENERATION WORKFLOW               │
└─────────────────────────────────────────────────────────┘

1. FETCH PRODUCTS
   Shopify API → Get in-stock products
   ↓
2. SELECT AUDIO
   AudioManager → Get mood based on day
              → Check 10-day history (SQLite)
              → Download audio file
   ↓
3. CREATE VIDEO
   VideoGenerator → Build clips (product images + text)
                 → Add music/audio
                 → Render with FFmpeg
   ↓
4. GENERATE METADATA
   SEOOptimizer → Generate YouTube-optimized title
              → Create description with CTAs
              → Generate tags for discoverability
   ↓
5. SAVE & OUTPUT
   Save video file (.mp4)
   Save metadata (.json)
```

---

## 📊 Key Features Breakdown

### ✅ YouTube Shorts (30 seconds)
**Structure**: Intro (3s) + Products (16s) + CTA (3s)

**Execution**:
```python
video_gen.create_shorts_video(products, audio_url)
# Returns: MoviePy VideoFileClip object
```

**Specs**:
- Duration: 30 seconds
- Resolution: 1080 x 1920 (vertical)
- Format: MP4 H.264
- Audio: Embedded royalty-free music

---

### ✅ Regular Videos (60-120 seconds)
**Rotation** (every 3 days):
1. **Style This** (90s) - Same product, different angles/styles
2. **Get Inspired** (100s) - Lifestyle with 3-4 products
3. **Out of the Week** (80s) - Weekly picks compilation
4. **Out of the Day** (75s) - Daily spotlight
5. **New Arrivals** (85s) - New products with excitement
6. **Best Sellers** (90s) - Top selling items

---

### ✅ Audio Management (10-day No-Repeat)
**Moods** (rotated daily):
- Happy 🎉
- Inspirational 💫
- Folk 🎸
- Rock 🔥
- Pop 💃

**Database Schema**:
```sql
CREATE TABLE audio_history (
    id INTEGER PRIMARY KEY,
    mood TEXT,
    audio_url TEXT,
    audio_title TEXT,
    used_date DATETIME,
    expires_date DATETIME  -- 10 days from use
)
```

**Logic**:
1. Query audio_history for mood
2. Exclude URLs with expires_date > now
3. Select random from remaining
4. Log usage with 10-day expiration
5. Cleanup expired entries weekly

---

### ✅ SEO Optimization
**Target Audience**: Women shoppers, USA

**Title Templates**:
```python
"✨ {Product} - Women's Trending Style 2025"
"💕 NEW: {Product} - Perfect for You"
"🛍️ Just Dropped - {Product} | Women Fashion"
```

**Description Elements**:
- Product list with prices
- Free shipping callout
- Product URLs
- Hashtags (20+)

**Tags** (30 max):
- Audience: womensfashion, womensshop, womensstyle
- Content: newarrivals, bestsellers, trending
- Action: shopnow, shoppinghaul, styleinspo
- Geography: usafashion, usaonline
- Products: auto-extracted from product titles

---

## 🛠️ API Reference

### ShopifyManager
```python
from shopify_manager import ShopifyManager

mgr = ShopifyManager()

# Get in-stock products (2-5)
products = mgr.get_instock_products(limit=2)
# Returns: [{"id": int, "title": str, "price": str, "url": str, ...}]

# Get collections
collections = mgr.get_collections()
# Returns: [{"id": int, "title": str, "handle": str}]

# Get products from collection
products = mgr.get_products_by_collection("summer-collection", limit=5)

# Get best sellers
products = mgr.get_best_sellers(limit=5)

# Get new arrivals
products = mgr.get_new_arrivals(limit=5)
```

### AudioManager
```python
from youtube_audio_manager import AudioManager

audio_mgr = AudioManager()

# Get available audio for mood
audio = audio_mgr.get_available_audio("happy")
# Returns: {"title": str, "url": str, "duration": int}

# Get mood for specific day
mood = audio_mgr.get_rotation_mood(day_index=5)
# Returns: "folk" (for day 5 % 5 = 0 → "happy", etc.)

# Get today's mood
mood = audio_mgr.get_daily_mood()

# Download audio file
audio_mgr.download_audio(url, "audio_cache/happy_1.mp3")

# View stats
stats = audio_mgr.get_audio_stats()
# Returns: {"happy": 3, "folk": 2, ...}

# Cleanup expired entries
audio_mgr.cleanup_expired()
```

### VideoGenerator
```python
from video_generator import VideoGenerator

video_gen = VideoGenerator()

# Create YouTube Short
video = video_gen.create_shorts_video(
    products=[{"title": "...", "price": "$99", ...}],
    audio_url="/path/to/audio.mp3"
)

# Create regular video
video = video_gen.create_regular_video(
    products=[...],
    audio_url="/path/to/audio.mp3",
    template_type="style_this"
)

# Render to file
video.write_videofile(
    "output.mp4",
    fps=30,
    codec='libx264',
    preset='ultrafast'
)
```

### SEOOptimizer
```python
from seo_optimizer import SEOOptimizer

seo = SEOOptimizer()

# Generate title
title = seo.generate_title(
    products=[...],
    video_type="shorts"  # or "regular"
)

# Generate description
desc = seo.generate_description(
    products=[...],
    video_type="shorts"
)

# Generate tags
tags = seo.generate_tags(
    products=[...],
    video_type="shorts",
    template="style_this"  # optional
)

# Get complete metadata package
metadata = seo.generate_metadata_bundle(
    products=[...],
    video_type="shorts",
    template=None
)
# Returns: {
#     "title": str,
#     "description": str,
#     "tags": [str],
#     "video_type": str,
#     "product_count": int,
#     "template": str
# }
```

---

## ⚙️ Configuration Options

### config.py
```python
# Video Settings
VIDEO_DURATION = 30              # seconds for shorts
VIDEO_WIDTH = 1080               # pixels
VIDEO_HEIGHT = 1920              # pixels (vertical)
VIDEO_FPS = 30                   # frames per second

# Audio
AUDIO_MOOD_ROTATION = ["happy", "inspirational", "folk", "rock", "pop"]
REPEAT_RESTRICTION_DAYS = 10

# Product Limits
MAX_PRODUCTS_SHORT = 2            # products per short
MAX_PRODUCTS_REGULAR = 5          # products per regular video

# Output
OUTPUT_DIR = "generated_videos"
SHORTS_DIR = "generated_videos/shorts"
REGULAR_DIR = "generated_videos/regular"
```

---

## 📝 Output File Formats

### Video File
```
shorts_20250513_120000.mp4
├── Format: MP4 (H.264 video, AAC audio)
├── Duration: 30 seconds
├── Resolution: 1080x1920
└── File size: 5-15 MB
```

### Metadata File
```json
{
  "title": "✨ New Product - Women's Fashion Trend 2025",
  "description": "🛍️ FEATURED PRODUCTS:\n\n• Product 1\n  Price: $99\n\n✨ SHOP WITH US...",
  "tags": ["womensfashion", "trending", "newarrivals", ...],
  "video_type": "shorts",
  "product_count": 2,
  "template": null
}
```

---

## 🔐 Security & Best Practices

### Credentials
- **Never** commit .env file to Git
- Store API keys securely
- Rotate credentials regularly
- Use IP whitelisting if available

### Audio
- Always use royalty-free music
- Maintain usage logs (done automatically)
- Check licenses before use
- Provide attribution if required

### Products
- Verify inventory before filming
- Handle out-of-stock gracefully
- Keep product images optimized
- Validate URLs before publishing

---

## 🚨 Error Handling

### Common Issues & Solutions

| Error | Cause | Solution |
|-------|-------|----------|
| "No in-stock products" | API permissions | Check Shopify credentials |
| "Video rendering slow" | CPU-intensive | Use `preset='ultrafast'` |
| "Audio not found" | URL invalid | Check audio sources in config |
| "Shopify connection failed" | Bad credentials | Verify .env file |
| "MoviePy error" | FFmpeg missing | `pip install imageio-ffmpeg` |

---

## 📊 Performance Metrics

### Resource Usage
- **Memory**: 500MB - 2GB (during rendering)
- **CPU**: Single core, ~80% during rendering
- **Disk**: ~20MB per video + cache

### Timing
- Product fetch: 1-2 seconds
- Audio selection: <1 second
- Video rendering: 3-8 minutes (depending on video length)
- Metadata generation: <1 second
- **Total per video**: 5-10 minutes

### Optimization Strategies
1. **Faster Rendering**: Use `preset='ultrafast'` ✓ (already set)
2. **Parallel Jobs**: Run multiple processes if CPU allows
3. **Pre-cache Audio**: Download common audio files
4. **Batch Operations**: Cache Shopify API responses

---

## 🔄 Maintenance Tasks

### Daily
- ✅ Monitor generated_videos folder
- ✅ Check for errors in logs

### Weekly
- 🧹 Cleanup expired audio history: `audio_mgr.cleanup_expired()`
- 📊 Review statistics: `print_stats()`

### Monthly
- 🔄 Rotate API credentials
- 📈 Review video analytics on YouTube
- 🎨 Update SEO keywords based on trends
- 🗑️ Archive old videos (optional)

---

## 📚 Dependencies Breakdown

```
moviepy==1.0.3          # Video creation/composition
├── numpy              # Array operations
└── imageio-ffmpeg     # FFmpeg backend (VIDEO CODEC)

pillow==10.0.0         # Image manipulation
requests==2.31.0       # HTTP requests
shopifyapi==14.4.0     # Shopify integration
python-dotenv==1.0.0   # Environment variables
sqlite3                # Built-in, audio tracking
```

---

## 🎬 Video Quality Checklist

Before uploading to YouTube:

- [ ] Video duration within 15-60 seconds
- [ ] Aspect ratio is 9:16 (vertical)
- [ ] Resolution is 1080x1920 minimum
- [ ] Audio is clear and royalty-free
- [ ] No copyright strikes likely
- [ ] Product images are clear
- [ ] CTA text is readable
- [ ] Title includes main keywords
- [ ] Description has product links
- [ ] Tags are relevant (max 30)

---

## 🚀 Scaling Up

### For Higher Volume
1. **Parallel Processing**: Run multiple instances
2. **Cloud Rendering**: AWS/GCP for faster rendering
3. **Product Expansion**: Add more collections
4. **Template Expansion**: Create more video templates
5. **Automation**: YouTube Data API for direct upload

### Multi-Collection Strategy
```python
# In youtube_shorts.py, add:
collections = shopify.get_collections()
for collection in collections:
    products = shopify.get_products_by_collection(collection['handle'])
    # Generate video
```

---

## 📞 Getting Help

**If you encounter issues:**

1. Check logs in console output
2. Review QUICK_START.md troubleshooting section
3. Verify Shopify API credentials
4. Check audio sources availability
5. Ensure FFmpeg is installed: `ffmpeg -version`

**Resources:**
- Shopify Docs: https://shopify.dev/docs/api
- MoviePy: https://zulko.github.io/moviepy/
- FFmpeg: https://ffmpeg.org/documentation.html
- YouTube Shorts: https://support.google.com/youtube/answer/9716234

---

## ✅ Checklist Before Going Live

- [ ] All 8 Python files installed
- [ ] requirements.txt installed
- [ ] .env file created and filled
- [ ] First test video generated successfully
- [ ] Metadata looks correct
- [ ] Automation scheduled (cron/Task Scheduler)
- [ ] Logs being captured
- [ ] Shopify API rate limits understood
- [ ] YouTube channel ready for uploads
- [ ] Audio licensing confirmed

**You're ready to launch! 🚀**
