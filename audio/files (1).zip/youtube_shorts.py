#!/usr/bin/env python3
"""
YouTube Shorts & Video Generator for Shopify
Generates 30-sec YouTube Shorts daily (with mood rotation & no repeat audio for 10 days)
Generates full-length videos every 3 days with rotating templates

Run manually: python youtube_shorts.py
Run daily via cron: 0 0 * * * /usr/bin/python3 /path/to/youtube_shorts.py
Run daily on Windows Task Scheduler with python.exe as executable
"""

import sys
import os
from datetime import datetime

# Add current directory to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from config import *
from shopify_manager import ShopifyManager
from youtube_audio_manager import AudioManager
from video_generator import VideoGenerator
from seo_optimizer import SEOOptimizer
from templates import (
    get_video_type_for_day,
    get_shorts_template,
    get_regular_template,
    print_schedule
)
from utils import (
    create_directories,
    get_output_path,
    save_metadata,
    format_products_for_display,
    print_summary,
    validate_shopify_config,
    print_stats
)


def generate_shorts(shopify_mgr, audio_mgr, video_gen, seo_opt):
    """Generate YouTube Short"""
    print("\n" + "="*60)
    print("🎬 GENERATING YOUTUBE SHORT")
    print("="*60)
    
    # Get products
    products = shopify_mgr.get_instock_products(limit=MAX_PRODUCTS_SHORT)
    
    if not products:
        print("❌ No in-stock products available")
        return False
    
    print(format_products_for_display(products))
    
    # Get audio
    mood = audio_mgr.get_daily_mood()
    print(f"\n🎵 Audio Mood: {mood.upper()}")
    
    try:
        audio = audio_mgr.get_available_audio(mood)
        print(f"✓ Audio selected: {audio['title']}")
    except Exception as e:
        print(f"❌ Audio selection failed: {str(e)}")
        return False
    
    # Create video
    try:
        print("\n📹 Creating video...")
        video = video_gen.create_shorts_video(products, audio['url'])
        
        output_path = get_output_path("shorts")
        print(f"💾 Rendering to: {output_path}")
        
        # Render with optimized settings for speed
        video.write_videofile(
            output_path,
            fps=VIDEO_FPS,
            codec='libx264',
            preset='ultrafast',  # Faster rendering
            verbose=False,
            logger=None
        )
        
        print(f"✅ Video created: {output_path}")
        
        # Generate metadata
        metadata = seo_opt.generate_metadata_bundle(
            products,
            video_type="shorts"
        )
        
        # Save metadata
        meta_path = save_metadata(metadata, output_path)
        
        # Print summary
        print_summary(output_path, metadata, 0.5)
        
        return True
    
    except Exception as e:
        print(f"❌ Video generation failed: {str(e)}")
        import traceback
        traceback.print_exc()
        return False


def generate_regular_video(shopify_mgr, audio_mgr, video_gen, seo_opt):
    """Generate regular video (every 3 days)"""
    print("\n" + "="*60)
    print("📹 GENERATING REGULAR VIDEO")
    print("="*60)
    
    # Determine day number for template rotation
    day_num = datetime.now().day
    
    # Get template
    template_type = get_regular_template(day_num)
    print(f"🎨 Template: {template_type.upper()}")
    
    # Get products based on template
    try:
        if template_type == "best_sellers":
            products = shopify_mgr.get_best_sellers(limit=MAX_PRODUCTS_REGULAR)
        elif template_type == "new_arrivals":
            products = shopify_mgr.get_new_arrivals(limit=MAX_PRODUCTS_REGULAR)
        else:
            products = shopify_mgr.get_instock_products(limit=MAX_PRODUCTS_REGULAR)
        
        if not products:
            print("❌ No in-stock products available")
            return False
        
        print(format_products_for_display(products))
    
    except Exception as e:
        print(f"❌ Product fetching failed: {str(e)}")
        return False
    
    # Get audio
    mood = audio_mgr.get_daily_mood()
    print(f"\n🎵 Audio Mood: {mood.upper()}")
    
    try:
        audio = audio_mgr.get_available_audio(mood)
        print(f"✓ Audio selected: {audio['title']}")
    except Exception as e:
        print(f"❌ Audio selection failed: {str(e)}")
        return False
    
    # Create video
    try:
        print(f"\n📹 Creating {template_type} video...")
        video = video_gen.create_regular_video(
            products,
            audio['url'],
            template_type
        )
        
        output_path = get_output_path("regular")
        print(f"💾 Rendering to: {output_path}")
        
        # Render with optimized settings
        video.write_videofile(
            output_path,
            fps=VIDEO_FPS,
            codec='libx264',
            preset='ultrafast',
            verbose=False,
            logger=None
        )
        
        print(f"✅ Video created: {output_path}")
        
        # Generate metadata
        metadata = seo_opt.generate_metadata_bundle(
            products,
            video_type="regular",
            template=template_type
        )
        
        # Save metadata
        meta_path = save_metadata(metadata, output_path)
        
        # Print summary
        print_summary(output_path, metadata, 1.5)
        
        return True
    
    except Exception as e:
        print(f"❌ Video generation failed: {str(e)}")
        import traceback
        traceback.print_exc()
        return False


def main():
    """Main execution"""
    print(f"\n{'='*60}")
    print(f"🎬 YouTube Video Generator")
    print(f"⏰ Started: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"{'='*60}\n")
    
    # Setup
    create_directories()
    
    if not validate_shopify_config():
        print("\n❌ Shopify configuration invalid")
        sys.exit(1)
    
    # Initialize managers
    try:
        shopify_mgr = ShopifyManager()
        audio_mgr = AudioManager()
        video_gen = VideoGenerator()
        seo_opt = SEOOptimizer()
    except Exception as e:
        print(f"\n❌ Initialization failed: {str(e)}")
        sys.exit(1)
    
    # Determine what to generate today
    day_num = datetime.now().day
    video_type = get_video_type_for_day(day_num)
    
    print(f"📅 Today's Schedule: {video_type.upper()}")
    
    try:
        if video_type == "shorts":
            success = generate_shorts(shopify_mgr, audio_mgr, video_gen, seo_opt)
        else:
            success = generate_regular_video(shopify_mgr, audio_mgr, video_gen, seo_opt)
        
        if success:
            print("\n✅ Generation completed successfully!")
            print_stats()
            
            # Show next schedule
            print("\n📅 Upcoming Schedule:")
            print_schedule()
        else:
            print("\n❌ Generation failed")
            sys.exit(1)
    
    except KeyboardInterrupt:
        print("\n\n⚠️ Generation interrupted by user")
        sys.exit(0)
    except Exception as e:
        print(f"\n❌ Unexpected error: {str(e)}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
    
    print(f"\n⏰ Completed: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"{'='*60}\n")


if __name__ == "__main__":
    main()
