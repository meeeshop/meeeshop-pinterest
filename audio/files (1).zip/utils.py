import os
import json
from datetime import datetime
from config import *

def create_directories():
    """Create output directories if they don't exist"""
    os.makedirs(SHORTS_DIR, exist_ok=True)
    os.makedirs(REGULAR_DIR, exist_ok=True)
    os.makedirs("audio_cache", exist_ok=True)
    print("✓ Output directories ready")


def generate_filename(video_type="shorts"):
    """Generate unique filename with timestamp"""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    return f"{video_type}_{timestamp}.mp4"


def get_output_path(video_type="shorts"):
    """Get full output path based on video type"""
    if video_type == "shorts":
        return os.path.join(SHORTS_DIR, generate_filename("shorts"))
    else:
        return os.path.join(REGULAR_DIR, generate_filename("regular"))


def save_metadata(metadata, output_path):
    """Save video metadata to JSON file"""
    try:
        json_path = output_path.replace('.mp4', '_metadata.json')
        
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump(metadata, f, ensure_ascii=False, indent=2)
        
        print(f"✓ Metadata saved: {json_path}")
        return json_path
    except Exception as e:
        print(f"✗ Error saving metadata: {str(e)}")
        return None


def load_metadata(json_path):
    """Load metadata from JSON file"""
    try:
        with open(json_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception as e:
        print(f"✗ Error loading metadata: {str(e)}")
        return None


def format_products_for_display(products):
    """Format products list for console display"""
    output = "\n📦 Selected Products:\n"
    for i, product in enumerate(products, 1):
        output += f"  {i}. {product['title']}\n"
        output += f"     Price: ${product['price']}\n"
        output += f"     URL: {product['url']}\n"
    return output


def get_audio_cache_path(audio_url):
    """Get cache path for audio file"""
    filename = audio_url.split('/')[-1] + ".mp3"
    return os.path.join("audio_cache", filename)


def print_summary(video_path, metadata, duration_minutes):
    """Print generation summary"""
    print("\n" + "="*60)
    print("✅ VIDEO GENERATED SUCCESSFULLY")
    print("="*60)
    print(f"\n📹 Output: {video_path}")
    print(f"⏱️ Duration: ~{duration_minutes} minute(s)")
    print(f"\n📝 TITLE:\n{metadata['title']}")
    print(f"\n📋 DESCRIPTION (First 200 chars):\n{metadata['description'][:200]}...")
    print(f"\n🏷️ TAGS ({len(metadata['tags'])} total):\n{', '.join(metadata['tags'][:10])}...")
    print(f"\n🛍️ PRODUCTS FEATURED: {metadata['product_count']}")
    print(f"\n📊 VIDEO TYPE: {metadata['video_type'].upper()}")
    if metadata.get('template'):
        print(f"🎨 TEMPLATE: {metadata['template']}")
    print("\n" + "="*60)


def validate_shopify_config():
    """Validate Shopify configuration"""
    if not SHOPIFY_API_KEY:
        print("✗ SHOPIFY_API_KEY not set in .env")
        return False
    if not SHOPIFY_API_PASSWORD:
        print("✗ SHOPIFY_API_PASSWORD not set in .env")
        return False
    if not SHOPIFY_STORE:
        print("✗ SHOPIFY_STORE not set in .env")
        return False
    
    print("✓ Shopify configuration valid")
    return True


def validate_environment():
    """Validate all environment setup"""
    checks = []
    
    # Check directories
    checks.append(("Output directories", os.path.exists(SHORTS_DIR)))
    
    # Check Shopify config
    checks.append(("Shopify credentials", validate_shopify_config()))
    
    # Check database
    checks.append(("Audio database", os.path.exists('database.db')))
    
    print("\n✓ Environment Validation Complete")
    return all(check[1] for check in checks)


def get_stats():
    """Get generation statistics"""
    shorts_count = len(os.listdir(SHORTS_DIR)) if os.path.exists(SHORTS_DIR) else 0
    regular_count = len(os.listdir(REGULAR_DIR)) if os.path.exists(REGULAR_DIR) else 0
    
    stats = {
        "shorts_generated": shorts_count,
        "regular_videos_generated": regular_count,
        "total_videos": shorts_count + regular_count,
        "timestamp": datetime.now().isoformat()
    }
    
    return stats


def print_stats():
    """Print generation statistics"""
    stats = get_stats()
    
    print("\n📊 GENERATION STATISTICS")
    print("=" * 40)
    print(f"YouTube Shorts: {stats['shorts_generated']}")
    print(f"Regular Videos: {stats['regular_videos_generated']}")
    print(f"Total Videos: {stats['total_videos']}")
    print("=" * 40)
