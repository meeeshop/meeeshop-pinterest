import os
from dotenv import load_dotenv

load_dotenv()

# Shopify Configuration
SHOPIFY_API_KEY = os.getenv("SHOPIFY_API_KEY")
SHOPIFY_API_PASSWORD = os.getenv("SHOPIFY_API_PASSWORD")
SHOPIFY_STORE = os.getenv("SHOPIFY_STORE", "meeeshop.myshopify.com")

# YouTube Audio Library Mood Categories
YOUTUBE_AUDIO_MOOD_MAP = {
    "happy": "happy upbeat background music",
    "inspirational": "inspirational motivational background music",
    "folk": "folk acoustic background music",
    "rock": "rock energy background music",
    "pop": "pop upbeat background music"
}

# Video Settings
VIDEO_DURATION = 30  # seconds for shorts
VIDEO_WIDTH = 1080
VIDEO_HEIGHT = 1920  # Vertical format
VIDEO_FPS = 30
AUDIO_MOOD_ROTATION = ["happy", "inspirational", "folk", "rock", "pop"]
REPEAT_RESTRICTION_DAYS = 10

# Output Directories
OUTPUT_DIR = "generated_videos"
SHORTS_DIR = f"{OUTPUT_DIR}/shorts"
REGULAR_DIR = f"{OUTPUT_DIR}/regular"

# SEO Keywords for Women Shoppers (USA)
SEO_KEYWORDS = {
    "women": ["women fashion", "women style", "women trends", "womens"],
    "usa": ["USA shipping", "US women", "USA", "american"],
    "collections": ["bestsellers", "new arrivals", "trending now", "style"]
}

# Video Templates
TEMPLATE_TYPES = [
    "style_this",
    "get_inspired", 
    "out_of_the_day",
    "out_of_the_week",
    "new_arrivals",
    "best_sellers"
]

# Audio Sources (Free)
AUDIO_SOURCES = {
    "happy": [
        "https://www.bensound.com/download/ukulele",
        "https://www.bensound.com/download/sunny",
        "https://www.bensound.com/download/gooey"
    ],
    "inspirational": [
        "https://www.bensound.com/download/dreams",
        "https://www.bensound.com/download/sunny",
        "https://www.bensound.com/download/energy"
    ],
    "folk": [
        "https://www.bensound.com/download/acoustic",
        "https://www.bensound.com/download/ukulele",
        "https://www.bensound.com/download/folk"
    ],
    "rock": [
        "https://www.bensound.com/download/energy",
        "https://www.bensound.com/download/rock",
        "https://www.bensound.com/download/adventure"
    ],
    "pop": [
        "https://www.bensound.com/download/pop",
        "https://www.bensound.com/download/sunny",
        "https://www.bensound.com/download/gooey"
    ]
}

# Colors and Branding
COLOR_PRIMARY = (220, 20, 60)  # Crimson Red
COLOR_SECONDARY = (255, 255, 255)  # White
COLOR_TEXT = (0, 0, 0)  # Black
COLOR_ACCENT = (255, 215, 0)  # Gold

# Product Limits
MAX_PRODUCTS_SHORT = 2
MAX_PRODUCTS_REGULAR = 5
