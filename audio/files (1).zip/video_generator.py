from moviepy.editor import *
from PIL import Image, ImageDraw, ImageFont
import numpy as np
import requests
from io import BytesIO
from config import *
import os

class VideoGenerator:
    """Generate YouTube Shorts and regular videos"""
    
    def __init__(self):
        self.width = VIDEO_WIDTH
        self.height = VIDEO_HEIGHT
        self.fps = VIDEO_FPS
    
    def create_shorts_video(self, products, audio_url, template_type="lifestyle"):
        """
        Create 30-second YouTube Short
        - Intro text (3s)
        - Product showcase (16s)
        - CTA closing (3s)
        """
        clips = []
        
        try:
            # Intro
            intro_clip = self._create_text_clip("🛍️ NEW IN STORE", duration=3)
            clips.append(intro_clip)
            
            # Product showcase
            for idx, product in enumerate(products[:2]):
                duration = 8 if len(products) == 1 else 7
                product_clip = self._create_product_clip(product, duration=duration)
                clips.append(product_clip)
            
            # CTA closing
            cta_clip = self._create_cta_clip(products[0], duration=3)
            clips.append(cta_clip)
            
            # Concatenate
            final_video = concatenate_videoclips(clips)
            
            # Add audio
            if os.path.exists(audio_url):
                audio_clip = AudioFileClip(audio_url).set_duration(final_video.duration)
            else:
                # Create silent audio if download failed
                audio_clip = mute_video(final_video)
            
            final_video = final_video.set_audio(audio_clip)
            
            return final_video
        
        except Exception as e:
            print(f"✗ Error creating shorts: {str(e)}")
            raise
    
    def create_regular_video(self, products, audio_url, template_type):
        """
        Create regular video (60-120s) with template style
        - Template-specific composition
        - Multiple products or angles
        """
        clips = []
        
        try:
            if template_type == "style_this":
                clips = self._template_style_this(products)
            elif template_type == "get_inspired":
                clips = self._template_get_inspired(products)
            elif template_type == "new_arrivals":
                clips = self._template_new_arrivals(products)
            elif template_type == "best_sellers":
                clips = self._template_best_sellers(products)
            elif template_type == "out_of_the_week":
                clips = self._template_out_of_week(products)
            elif template_type == "out_of_the_day":
                clips = self._template_out_of_day(products)
            else:
                clips = self._template_get_inspired(products)
            
            # Concatenate
            final_video = concatenate_videoclips(clips)
            
            # Add audio
            if os.path.exists(audio_url):
                audio_clip = AudioFileClip(audio_url).set_duration(final_video.duration)
            else:
                audio_clip = mute_video(final_video)
            
            final_video = final_video.set_audio(audio_clip)
            
            return final_video
        
        except Exception as e:
            print(f"✗ Error creating regular video: {str(e)}")
            raise
    
    def _create_product_clip(self, product, duration=8):
        """Create clip with product image and overlay text"""
        img = Image.new('RGB', (self.width, self.height), color=(245, 245, 245))
        
        try:
            # Fetch and paste product image
            if product['image']:
                response = requests.get(product['image'], timeout=5)
                product_img = Image.open(BytesIO(response.content))
                product_img.thumbnail((self.width - 40, self.height - 300), Image.Resampling.LANCZOS)
                
                x = (self.width - product_img.width) // 2
                y = 80
                img.paste(product_img, (x, y))
        except Exception as e:
            print(f"✗ Could not load image: {str(e)}")
        
        # Add text overlay
        draw = ImageDraw.Draw(img)
        
        try:
            font_title = ImageFont.truetype("arial.ttf", 40)
            font_price = ImageFont.truetype("arial.ttf", 50)
        except:
            font_title = ImageFont.load_default()
            font_price = ImageFont.load_default()
        
        # Product title
        title_text = product['title'][:35]
        draw.text((20, self.height - 250), title_text, fill=COLOR_TEXT, font=font_title)
        
        # Price
        price_text = f"${product['price']}"
        draw.text((20, self.height - 180), price_text, fill=COLOR_PRIMARY, font=font_price)
        
        # CTA
        draw.text((20, self.height - 80), "👉 Link in Bio", fill=(0, 100, 200), font=font_title)
        
        # Convert to video clip
        img_array = np.array(img)
        clip = ImageClip(img_array).set_duration(duration)
        
        return clip
    
    def _create_text_clip(self, text, duration=3, color='white'):
        """Create full-screen text overlay"""
        try:
            clip = TextClip(
                text,
                fontsize=80,
                color=color,
                font='Arial-Bold',
                method='caption',
                size=(self.width - 40, None)
            )
            clip = clip.set_position('center').set_duration(duration)
            
            # Add background
            bg = ColorClip(size=(self.width, self.height), color=(20, 20, 20))
            return CompositeVideoClip([bg, clip])
        except Exception as e:
            print(f"✗ Error creating text clip: {str(e)}")
            # Fallback: colored background
            bg = ColorClip(size=(self.width, self.height), color=(50, 50, 50))
            return bg.set_duration(duration)
    
    def _create_cta_clip(self, product, duration=3):
        """Create Call-to-Action closing clip"""
        img = Image.new('RGB', (self.width, self.height), color=COLOR_PRIMARY)
        draw = ImageDraw.Draw(img)
        
        try:
            font_large = ImageFont.truetype("arial.ttf", 90)
            font_small = ImageFont.truetype("arial.ttf", 45)
        except:
            font_large = font_small = ImageFont.load_default()
        
        # Main CTA
        draw.text(
            (self.width // 2 - 150, self.height // 2 - 150),
            "SHOP NOW",
            fill=COLOR_SECONDARY,
            font=font_large
        )
        
        # Product name
        title_short = product['title'][:25]
        draw.text(
            (20, self.height // 2 + 50),
            title_short,
            fill=COLOR_SECONDARY,
            font=font_small
        )
        
        # Link CTA
        draw.text(
            (20, self.height // 2 + 150),
            "Link in Bio 👆",
            fill=COLOR_SECONDARY,
            font=font_small
        )
        
        img_array = np.array(img)
        clip = ImageClip(img_array).set_duration(duration)
        
        return clip
    
    # Template Methods
    def _template_style_this(self, products):
        """Show styling ideas with same products from different angles"""
        clips = [self._create_text_clip("Style This ✨", duration=2)]
        for product in products:
            clips.append(self._create_product_clip(product, duration=10))
        return clips
    
    def _template_get_inspired(self, products):
        """Lifestyle inspiration with multiple products"""
        clips = [self._create_text_clip("Get Inspired 💕", duration=2)]
        for product in products[:3]:
            clips.append(self._create_product_clip(product, duration=12))
        return clips
    
    def _template_new_arrivals(self, products):
        """New products with excitement"""
        clips = [self._create_text_clip("NEW ARRIVALS 🎉", duration=3)]
        for product in products[:3]:
            clips.append(self._create_product_clip(product, duration=10))
        return clips
    
    def _template_best_sellers(self, products):
        """Top selling items"""
        clips = [self._create_text_clip("BEST SELLERS ⭐", duration=2)]
        for product in products[:3]:
            clips.append(self._create_product_clip(product, duration=12))
        return clips
    
    def _template_out_of_week(self, products):
        """Weekly picks"""
        clips = [self._create_text_clip("Out Of The Week 📅", duration=2)]
        for product in products[:4]:
            clips.append(self._create_product_clip(product, duration=10))
        return clips
    
    def _template_out_of_day(self, products):
        """Daily style spotlight"""
        clips = [self._create_text_clip("Out Of The Day ☀️", duration=2)]
        for product in products[:2]:
            clips.append(self._create_product_clip(product, duration=15))
        return clips
